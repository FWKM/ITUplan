$(function(){
	$('#cal').datepicker({ firstDay: 1 });
});
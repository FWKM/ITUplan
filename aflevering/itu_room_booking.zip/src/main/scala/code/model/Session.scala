package code.model

import net.liftweb._
import util._
import Helpers._
import common._
import http._
import sitemap._
import Loc._
import net.liftweb.mapper._
import java.sql._

import net.liftweb.http.ResourceServer
import scala.xml.NodeSeq
import net.liftweb.http.{LiftRules}
import net.liftweb.http.js._
import net.liftweb.http.S._
import net.liftweb.util.Helpers._
import JsCmds._
import JE._

object Session{
	object loggedIn extends SessionVar[Int](0)
	object uid extends SessionVar[Int](-1)
	object currentRoom extends SessionVar[String]("-1")
}
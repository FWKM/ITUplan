package code.model
import java.sql._
import java.util.Calendar
import java.text.SimpleDateFormat
import code.model._

object Database {
	
	var conn : Connection = null
	var cal = Calendar.getInstance()
	val date = today
	
	def connect = {
		if(conn == null){
			Class.forName("com.mysql.jdbc.Driver")
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ituplan","root","")
		}
	}
	
	def bookRoom(uid : Int = Session.uid.is, rid : Int, from : Int = now, to: Int = now + 240) : Booking = {
		connect
		val stm = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
		val q = ("INSERT INTO booking (uid,rid,time,endtime,year,month,day,duration) VALUES (%d,%d,%d,%d,%d,%d,%d, %d)").format(uid,rid,from,to,date(0).toInt,date(1).toInt, date(2).toInt,to-from)
		stm.executeUpdate(q)
		// Create a booking object to return
		val bidq = (("SELECT b.id, r.rid FROM booking AS b JOIN room AS r ON b.rid = r.id WHERE uid = %d ORDER BY id DESC LIMIT 1").format(uid))
		var bid = -1
		var room = ""
		val res = stm.executeQuery(bidq)
		while(res.next()) {
			bid = res.getInt(1)
			room = res.getString(2)
		}
		new Booking(bid,uid,room,from,to,date,true)
	}
	
	def now = {
		val sdf = new SimpleDateFormat("HH:mm")
		val time = ( sdf.format(cal.getTime()) ).split(":")
		var h = (time(0).toInt) * 60
		var m = time(1).toInt
		if( m < 30 ) m = 0
		else if( m < 45 ) m = 30
		else{
			m = 0
			h = h + 60
		}
		m + h
	}
	
	def getBookings(uid : Int) = {
		connect
		val stm = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
		val q = ("SELECT * FROM booking WHERE uid = '%s'").format(uid)
		stm.executeQuery(q)
	}
	
	def cancelBooking(bid : Int) = {
		connect
		val stm = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
		val q = ("DELETE FROM booking WHERE id = %d").format(bid)
		stm.executeUpdate(q)
	}
	
	def login(usr : String,pwd : String) : Int = {
		var uid = -1
		connect
		val stm = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
		val q = ("SELECT id FROM user WHERE mail = '%s' AND pwd = '%s' LIMIT 1").format(usr,pwd)
		val res = stm.executeQuery(q)
		while(res.next()) uid = res.getInt(1)
		uid
	}
	
	/*
	 * Returns a room that is currently avaliable for minimum 1 hour
	 * Queries the database for a room that is not in the bookings-table with the date of today
	 */
	def findRoomNow : Int = {
		connect
		val stm = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
		val time = now
		val q = ("SELECT room.id FROM room WHERE room.id NOT IN ( SELECT room.id FROM room JOIN booking AS b ON room.id = b.rid WHERE b.year = %d AND b.month = %d AND b.day = %d AND b.endtime > %d AND b.time < %d ) ORDER BY room.capacity LIMIT 1").format( today(0).toInt, today(1).toInt, today(2).toInt, time.toInt, time.toInt + 240)
		var roomID = -1
		try{
			val res = stm.executeQuery(q)
			while(res.next()) roomID = res.getInt(1)
			roomID
		}
		catch{
			case e: Exception => println(e)
			roomID
		}
	}
	
	def disconnect{
		if(conn != null) conn.close()
	}
	
	def today = {
	    val now = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime())
		now.split('-')
	}
	
	
	def populateTestData = {
		connect
		val stm = conn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)
		val N_BOOKINGS = 20
		val user_ids = List(1,2,3)
		val date = today
		var days = List() : List[Int]
		var rand = new java.util.Random()
		var nextMonth = false
		for(i <- ( 0.until(7) ) ){
			if(date(2).toInt+i > 30) {
				days = days:+((date(2).toInt+i) - 29)
				nextMonth = true
			}
			else days = days:+(date(2).toInt+i)
		}
		for(i <- (0.until(N_BOOKINGS))){
			var day = days( rand.nextInt(7) ).toInt
			val month = if(nextMonth) (date(1)).toInt else date(1).toInt
			val year = date(0).toInt
			val uid = 0
			val rid = rand.nextInt(28) + 4
			val time = (rand.nextInt(9) + 7) * 60
			val duration = (rand.nextInt(10) + 1) * 30
			var endtime = time + duration;
			val q = "INSERT INTO booking (uid,rid,time,endtime,year,month,day, duration) VALUES(%d,%d,%d,%d,%d,%d,%d, %d)".format(uid,rid,time,endtime,year,month,day, duration)
			stm.executeUpdate(q)
			
		}
	}
}
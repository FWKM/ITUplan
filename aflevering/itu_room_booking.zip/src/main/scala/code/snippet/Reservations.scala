package code.snippet

import net.liftweb._
import http._
import net.liftweb.util._
import net.liftweb.common._
import scala.xml._
import net.liftweb.http.SHtml._
import net.liftweb.http.js.JsCmds._
import net.liftweb.http.js.JE._
import net.liftweb.http._
import net.liftweb.http.js._
import net.liftweb.util.Helpers._

import JsCmds._
import JE._
import net.liftweb.http.S._
import code.model._

class Reservations {/*
	def render = {
	        bind("search", renderReservations(),
          	"list:content" -> <li>this</li>)
	}
	
	def renderReservations = {
		val res = Database.getBookings(Session.uid.is)
		res('time').toString(convert(func(x)->x/60))
		res('endtime').toString(convert(func(x)->x/60))
	}
*/}
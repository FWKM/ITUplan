package code.model

class Booking(bid : Int, uid : Int, rid : String, time : Int, endtime : Int, date : Array[String], confirmed : Boolean){
	val bookingID = bid
	val userID = uid
	val roomID = rid
	val startTime = time
	val endTime = endtime
	val year = date(0).toInt
	val month = date(1).toInt
	val day = date(2).toInt
	var bookingConfirmed = confirmed
}
package code.model

import net.liftweb._
import util._
import Helpers._
import common._
import http._
import sitemap._
import Loc._
import net.liftweb.mapper._
import java.sql._

import net.liftweb.http.ResourceServer
import scala.xml.NodeSeq
import net.liftweb.http.{LiftRules}
import net.liftweb.http.js._
import net.liftweb.http.S._
import net.liftweb.util.Helpers._
import JsCmds._
import JE._

object Global{
	def fromMinutes(mins : Int) = {
		val h = mins / 60
		val m = mins % 60
		val minutes = if(m < 10) ("0"+m) else m
		(h + ":" + minutes)
	}
	// Assume time is in hh:mm format
	def fromTime(time : String) = {
		var arr = time.split(":")
		var h = arr(0).toInt
		var m = arr(1).toInt
		h * 60 + m
	}
	def main(args : scala.Array[String]) {
		println(fromTime("10:00"))
		println(fromMinutes(600))
	}
}
package code.snippet

import net.liftweb._
import http._
import net.liftweb.util._
import net.liftweb.common._
import scala.xml._
import net.liftweb.http.SHtml._
import net.liftweb.http.js.JsCmds._
import net.liftweb.http.js.JE._
import net.liftweb.http._
import net.liftweb.http.js._
import net.liftweb.util.Helpers._
import JsCmds._
import JE._
import net.liftweb.http.S._
import code.model._

class RoomBooking {
	def render = {
		
        val funcName = Helpers.nextFuncName
        val func = (timespan : String) => {
			println(timespan)
		}
        addFunctionMap(funcName, contextFuncBuilder(func))

        val onLoad ="""
		$(function() {
			// AVAILABILITY GRID
			var dom = $("#theGrid");
			var html = "<ul>";
			var date = new Date();
			var today = new Date();
			html = html + '<li class="topLabel">';
			html = html + '<span class="label">&nbsp;</span>';
			for(var j = 7; j < 21; j++){
				var t = j;
				t30 = j + 30;
				html = html + '<div class="timeBlock block'+t*60+'">'+t+'</div>';
				if(j != 20) {
					html = html + '<div class="timeBlock block'+t30+'">'+t+'.30</div>';
				}
			}
			html = html + '</li>';
			for(var i = 0; i < 7; i++){
				var theDate = toWeekday(date.getDay());
				if(date.getDate() == today.getDate()) theDate = 'Today';
				html = html + '<li class="day'+i+'"><span class="label">'+theDate+'</span>';
				for(var j = 7; j < 21; j++){
					t = j * 60;
					t30 = t + 30;
					html = html + '<div class="timeBlock block'+t+'"></div>';
					if(j != 20) {
						html = html + '<div class="timeBlock block'+t30+'"></div>';	
					}
				}
				html = html + '</li>';
			  	date.setDate( date.getDate() + 1 );
			}
			html = html + '</ul>';
			dom.html(html);

			// AVAILABILITY GRID HOVER
			$("#theGrid li").not(".topLabel").find(".timeBlock").hover(function(){
				var timeSelector = (($(this).attr('class')).split(" "))[1];
				var daySelector = $(this).parent().attr('class');
				var timeLabel = $("#theGrid ul li.topLabel").find("."+timeSelector);
				var dayLabel = $("#theGrid ul").find("li."+daySelector);

				var arr = [timeLabel,dayLabel];
				for(var i in arr) arr[i].css('color','#f7b54a');

			},function(){
				var timeSelector = (($(this).attr('class')).split(" "))[1];
				var daySelector = $(this).parent().attr('class');
				var timeLabel = $("#theGrid ul li.topLabel").find("."+timeSelector);
				var dayLabel = $("#theGrid ul").find("li."+daySelector);

				var arr = [timeLabel,dayLabel];
				for(var i in arr) arr[i].css('color','#3C3C3C');
			});

			// AVAILABILITY GRID CLICK

			var beginTime, endTime, date, beginIndex;
			var beginClick = false;

			$("#theGrid li").not(".topLabel").find(".timeBlock").click(function(){
				beginClick = (!beginClick);
				var timeSelector = (($(this).attr('class')).split(" "))[1];
				var timeLabel = $("#theGrid ul li.topLabel").find("."+timeSelector);
				var dayOffset = ($(this).parent().attr('class')).split("day")[1];
				var day = new Date();
				day.setDate( day.getDate() + parseInt(dayOffset) );
				$(this).css('backgroundColor','green');

				// If this is the first click, store the values
				if(beginClick){
					// The time clicked
					beginTime = timeLabel.html().replace('.',':');

					// The date clicked, in custom format
					date = formatDate(day);

					// The index of first div to be painted
					beginIndex = findIndex($(this));

					// Clear 'selected' classes
					$("#theGrid .timeBlock").removeClass('selected');
				}
				// If this is the second click, show the timespan on the grid, and calculate the 
				// duration. Remember to check for errors
				else{
					var endIndex = findIndex($(this));
					$($(this).parent().find('div').each(function(index){
						if(index >= beginIndex && index <= endIndex){
							$(this).addClass("selected");
						}
					}));
					var timeSelector = (($(this).attr('class')).split(" "))[1];
					var timeLabel = $("#theGrid ul li.topLabel").find("."+timeSelector);
					endTime = timeLabel.html().replace('.',':');
					var res = beginTime + ' ' + endTime + ' ' + date + ' ' + $("h2#room").html();
					liftAjax.lift_ajaxHandler('""" + funcName + """='+res, null, null, null);
				}
			});


			// MISC FUNCTIONS
			function findIndex(obj){
				var parent = obj.parent();
				var theIndex = -1;
				$(parent).find('div').each(function(index){
					if(obj.attr('class') == $(this).attr('class')){
						theIndex = index;
					}
				});
				return theIndex;
			}

			function formatDate(date){
				var day = date.getDate();
				var month = date.getMonth()+1;
				var year = date.getFullYear();
				return year+"/"+month+"/"+day;
			}

			function toWeekday(i){
				switch(i){
					case 0: return "Sunday";
					case 1: return "Monday";
					case 2: return "Tuesday";
					case 3: return "Wedensday";
					case 4: return "Thursday";
					case 5: return "Friday";
					case 6: return "Saturday";
				}
			}

		}); """
		
		<head>
        	<script type="text/javascript" charset="utf-8">{onLoad}</script>
        </head>
	}
	
	def renderRoom(xhtml : NodeSeq) : NodeSeq = {
		bind("obj", xhtml, "room" -> Text(Session.currentRoom.is) )
	}
}




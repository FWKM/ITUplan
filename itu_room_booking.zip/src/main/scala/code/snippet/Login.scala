package code.snippet

import net.liftweb._
import http._
import net.liftweb.util._
import net.liftweb.common._
import scala.xml._
import net.liftweb.util.BindHelpers._
import net.liftweb.http.SHtml._
import net.liftweb.http.js.JsCmds._
import net.liftweb.http.js.JE._
import net.liftweb.http._
import net.liftweb.http.js._
import code.model._
import net.liftweb.util.Log
import code.model._

class Login {
    def render = {
		var name = ""
		var pwd = ""
		def process(){
			val uid = Database.login(name,pwd)
			if(uid != -1){
				Session.loggedIn.apply(1)
				Session.uid.apply(uid)
			}
			else{
				S.error("Username or password incorrect")
			}
		}
		"name=username" #> SHtml.onSubmit(name = _) &
		"name=pwd" #> SHtml.onSubmit(pwd = _) &
		"type=submit" #> SHtml.onSubmitUnit(process)
    }
}
package code.snippet

import net.liftweb._
import http._
import net.liftweb.util._
import net.liftweb.common._
import scala.xml._
import net.liftweb.http.SHtml._
import net.liftweb.http.js.JsCmds._
import net.liftweb.http.js.JE._
import net.liftweb.http._
import net.liftweb.http.js._
import net.liftweb.util.Helpers._

import JsCmds._
import JE._
import net.liftweb.http.S._
import code.model._

class Frontpage {
	
    def render = {
        val funcName = Helpers.nextFuncName
		val funcName2 = Helpers.nextFuncName
		val funcName3 = Helpers.nextFuncName
        val func = (uid : String) => {
			Session.currentRoom.apply(uid)
			JsCmds.RedirectTo("room-booking")
		}
		val func2 = () => {
			var roomid = Database.findRoomNow
			if(roomid != -1){
				var booking = Database.bookRoom(rid = roomid)
				//var booking = new Booking(0,4,"3A12",1120,1180,Array("2011","5","15"), true)
				var a = """'<div id="receipt"><pre><h2>Room """+booking.roomID+""" was booked:</h2><div id="content">Date:	"""+booking.day+"""/"""+booking.month+"""/"""+booking.year+"""<br/>From: 	""" +Global.fromMinutes(booking.startTime)+"""<br/>To:		"""+Global.fromMinutes(booking.endTime)+"""</div><button id="quickBookCancel">Cancel</button><button id="quickBookOK">OK</button></pre></div>'"""
				
				Run("""$('#bookingReceipt').append("""+a+""");
					$('body').css('overflow','hidden');
					$('#overlay').show(); 
					$('#receipt #quickBookCancel').click(function(){ 
						liftAjax.lift_ajaxHandler('""" + funcName3 + """='+"""+booking.bookingID+""", null, null, null);
						$('#overlay').hide();
						$('#receipt').remove();
						$('body').css('overflow','visible');
					});
					$('#receipt #quickBookOK').click(function(){
						$('#overlay').hide();
						$('#receipt').remove();
						$('body').css('overflow','visible');
					})""")
			}
			else{
				// Display "No room" notice
				println("No rooms!")
			}
		}
		val func3 = (bid : String) => {
			Database.cancelBooking(bid.toInt)
		}
        addFunctionMap(funcName, contextFuncBuilder(func))
        addFunctionMap(funcName2, contextFuncBuilder(func2))
        addFunctionMap(funcName3, contextFuncBuilder(func3))


        val onLoad ="""jQuery(document).ready(function(){
                     jQuery('area').click(function(){
                       var uid = $(this).attr('id');
                       liftAjax.lift_ajaxHandler('""" + funcName + """='+uid, null, null, null);
                     });
                     jQuery('#quickfind').click(function(){
                       var uid = $(this).attr('id');
                       liftAjax.lift_ajaxHandler('""" + funcName2 + """='+uid, null, null, null);
                     });
                   });
                   """
		<head>
            <script type="text/javascript" charset="utf-8">{onLoad}</script>
        </head> 
    }
    
}
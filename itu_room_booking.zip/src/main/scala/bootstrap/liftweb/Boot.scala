package bootstrap.liftweb

import net.liftweb._
import util._
import Helpers._
import common._
import http._
import sitemap._
import Loc._
import net.liftweb.mapper._
import java.sql._

import net.liftweb.http.ResourceServer
import scala.xml.NodeSeq
import net.liftweb.http.{LiftRules}
import net.liftweb.http.js._
import net.liftweb.http.S._
import net.liftweb.util.Helpers._
import JsCmds._
import JE._
import code.model._

object DBVendor extends ConnectionManager{
	Class.forName("com.mysql.jdbc.Driver")
	
	def newConnection(name : ConnectionIdentifier) = { 
		try {
			Full(DriverManager.getConnection( "jdbc:mysql://localhost/ituplan", "root", ""))
		} catch { case e : Exception => e.printStackTrace; Empty } 
	}
	
	def releaseConnection (conn : Connection) { conn.close }
}


class Boot {
  def boot {
    LiftRules.addToPackages("code")
	DB.defineConnectionManager(DefaultConnectionIdentifier, DBVendor)
    
    LiftRules.ajaxStart = Full(() => LiftRules.jsArtifacts.show("ajax-loader").cmd)
    LiftRules.ajaxEnd = Full(() => LiftRules.jsArtifacts.hide("ajax-loader").cmd)
    
	LiftRules.htmlProperties.default.set((r:Req) => new Html5Properties(r.userAgent) )
	
	// Sitemap and user control
	def isLoggedIn() = (Session.loggedIn.is == 1)
	
	val AuthRequired = If(
	     () => isLoggedIn,/*isLoggedIn.get*/
	     () => RedirectResponse("login"))
	
	val LoginAuth = If(
		() => !isLoggedIn,
		() => RedirectResponse("index"))
	
	val siteMap = SiteMap(
		Menu("Index") / "index"
		>> AuthRequired >> Hidden,
		Menu("Advanced") / "advanced"
		>> Hidden,
		Menu("RoomBooking") / "room-booking"
		>> AuthRequired >> Hidden,
	     Menu("Login") / "login"
	     >> LoginAuth >> Hidden,
		Menu("Your Reservations") / "reservations"
	     >> AuthRequired,
	     Menu("Logout") / "logout"
	    >> EarlyResponse(() => {
			Session.loggedIn.apply(0)
	        Full(RedirectResponse("login"))
	     }))

	LiftRules.setSiteMap(siteMap)
  }
}

